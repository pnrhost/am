<?php
include "includes/header.php";
?>
<link rel="stylesheet" type="text/css" href="css/index.css">
<link rel="stylesheet" type="text/css" href="css/auction.css">
<div class="content_wrapper">
   <div class="col-md-12">
  <!-- Category -->
  <div class="single category">
    <h3 class="side-title">Category</h3>
    <ul class="list-unstyled">
      <li><a href="products.php" title="">Business <span class="pull-right"><i class="fa fa-angle-right"></i></span></a></li>
      <li><a href="products.php" title="">Technology <span class="pull-right"><i class="fa fa-angle-right"></i></span></a></li>
      <li><a href="products.php" title="">Web <span class="pull-right"><i class="fa fa-angle-right"></i></span></a></li>
      <li><a href="products.php" title="">Ecommerce <span class="pull-right"><i class="fa fa-angle-right"></i></span></a></li>
      <li><a href="products.php" title="">Wordpress <span class="pull-right"><i class="fa fa-angle-right"></i></span></a></li>
      <li><a href="products.php" title="">Android <span class="pull-right"><i class="fa fa-angle-right"></i></span></a></li>
      <li><a href="products.php" title="">IOS <span class="pull-right"><i class="fa fa-angle-right"></i></span></a></li>
      <li><a href="products.php" title="">Windows <span class="pull-right"><i class="fa fa-angle-right"></i></span></a></li>
    </ul>
   </div>
 </div>
</div>
<div class="space-clear-10"></div>
<?php
include "includes/footer.html";
?>