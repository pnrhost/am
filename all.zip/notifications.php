<?php
include "includes/header.php";
?>
<link rel="stylesheet" type="text/css" href="css/index.css">
<link rel="stylesheet" type="text/css" href="css/auction.css">

<?php  include "includes/title.php"; ?>
 
<div class="content_wrapper">
  <hr>
  <div class="col-sm-12 ">



    <div class="alert alert-success notifications">
    brian has placed a bid of $6000 on your auction: Honda Fit 2015
    <br><b>April 24, 2018, 5:27 p.m.</b>
    
    <a href="http://auctionmail.herokuapp.com/my/auction/item9/bids/">View</a>
    

    </div>




    <div class="alert alert-success notifications">
    brian has placed a bid of $5800 on your auction: Honda Fit 2015
    <br><b>April 24, 2018, 4:50 p.m.</b>
    
    <a href="http://auctionmail.herokuapp.com/my/auction/item9/bids/">View</a>
    

    </div>




    <div class="alert alert-success notifications">
    susan has placed a bid of $5600 on your auction: Honda Fit 2015
    <br><b>April 24, 2018, 4:34 p.m.</b>
    
    <a href="http://auctionmail.herokuapp.com/my/auction/item9/bids/">View</a>
    

    </div>




    <div class="alert alert-success notifications">
    susan has placed a bid of $5300 on your auction: Honda Fit 2015
    <br><b>April 24, 2018, 4:33 p.m.</b>
    
    <a href="http://auctionmail.herokuapp.com/my/auction/item9/bids/">View</a>
    

    </div>




    <div class="alert alert-success notifications">
    susan has placed a bid of $5000 on your auction: Honda Fit 2015
    <br><b>April 24, 2018, 4:32 p.m.</b>
    
    <a href="http://auctionmail.herokuapp.com/my/auction/item9/bids/">View</a>
    

    </div>




    <div class="alert alert-success notifications">
    "Samsung S7" - Auction Closed, with a winning bid of $330.00 submitted by brian. You can get in touch with the winner by message or via email brian@vacancymail.co.zw, telephone 07736363663 to arrange for delivery and payment. Thank you for your participation.
    <br><b>April 2, 2018, 11:20 a.m.</b>
    
    <a href="https://auctionmail.herokuapp.com/my/auction/item6/">View</a>
    

    </div>




    <div class="alert alert-success notifications">
    brian has placed a bid of $330 on your auction: Samsung S7
    <br><b>March 28, 2018, 12:17 p.m.</b>
    
    <a href="https://auctionmail.herokuapp.com/my/auction/item6/bids/">View</a>
    

    </div>




    <div class="alert alert-success notifications">
    brian has placed a bid of $320 on your auction: Samsung S7
    <br><b>March 28, 2018, 12:16 p.m.</b>
    
    <a href="https://auctionmail.herokuapp.com/my/auction/item6/bids/">View</a>
    

    </div>




    <div class="alert alert-success notifications">
    susan has placed a bid of $240 on your auction: Samsung S7
    <br><b>March 28, 2018, 11:05 a.m.</b>
    
    <a href="https://auctionmail.herokuapp.com/my/auction/item6/bids/">View</a>
    

    </div>




    <div class="alert alert-success notifications">
    brian has placed a bid of $220 on your auction: Samsung S7
    <br><b>March 28, 2018, 10:56 a.m.</b>
    
    <a href="https://auctionmail.herokuapp.com/my/auction/item6/bids/">View</a>
    

    </div>




    <div class="alert alert-success notifications">
    susan has placed a bid of $215 on your auction: Samsung S7
    <br><b>March 28, 2018, 10:56 a.m.</b>
    
    <a href="http://auctionmail.herokuapp.com/my/auction/item6/bids/">View</a>
    

    </div>




    <div class="alert alert-success notifications">
    brian has placed a bid of $210 on your auction: Samsung S7
    <br><b>March 28, 2018, 10:55 a.m.</b>
    
    <a href="https://auctionmail.herokuapp.com/my/auction/item6/bids/">View</a>
    

    </div>




    <div class="alert alert-success notifications">
    susan has placed a bid of $206 on your auction: Samsung S7
    <br><b>March 28, 2018, 10:55 a.m.</b>
    
    <a href="http://auctionmail.herokuapp.com/my/auction/item6/bids/">View</a>
    

    </div>




    <div class="alert alert-success notifications">
    brian has placed a bid of $200 on your auction: Samsung S7
    <br><b>March 28, 2018, 10:54 a.m.</b>
    
    <a href="https://auctionmail.herokuapp.com/my/auction/item6/bids/">View</a>
    </div>
</div>
</div>


<div class="space-clear-10"></div>
<?php
include "includes/footer.html";
?>
