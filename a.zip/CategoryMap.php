<?php
include "includes/header.php";
?>
<link rel="stylesheet" type="text/css" href="css/index.css">


<div class="container">
<div class="row">

         <div class="col-sm-2 sidenav categories">

  <ul class="nav ">
  <h5 style="color: orange">Browse Categories</h5>
 <li><a href="#" title="Antiques &amp; Collectables">Antiques &amp; Collectables</a></li>
<li><a href="#" title="Art">Art</a></li>
<li><a href="#" title="Baby">Baby</a></li>
<li><a href="#" title="Bikes, Boats &amp; Other Vehicles">Bikes, Boats &amp; Other Vehicles</a></li>
<li><a href="#" title="Books &amp; Education">Books &amp; Education</a></li>
<li><a href="#" title="Business, Farming &amp; Industry">Business, Farming &amp; Industry</a></li>
<li><a href="#" title="Car Parts &amp; Accessories">Car Parts &amp; Accessories</a></li>
<li><a href="#" title="Cars">Cars</a></li>
<li><a href="#" title="Cell Phones &amp; Accessories">Cell Phones &amp; Accessories</a></li>
<li><a href="#" title="Clothing, Shoes &amp; Accessories">Clothing, Shoes &amp; Accessories</a></li>
<li><a href="#" title="Coins &amp; Notes">Coins &amp; Notes</a></li>
<li><a href="#" title="Computers &amp; Networking">Computers &amp; Networking</a></li>
<li><a href="#" title="Crafts">Crafts</a></li>
<li><a href="#" title="Electronics">Electronics</a></li>
<li><a href="#" title="Gaming">Gaming</a></li>
<li><a href="#" title="Garden, Outdoor Living &amp; Pets">Garden, Outdoor Living &amp; Pets</a></li>
<li><a href="#" title="Gemstones &amp; Rocks">Gemstones &amp; Rocks</a></li>
<li><a href="#" title="Gift Vouchers &amp; Coupons">Gift Vouchers &amp; Coupons</a></li>
<li><a href="#" title="Health &amp; Beauty">Health &amp; Beauty</a></li>
<li><a href="#" title="Holistic &amp; Esoteric">Holistic &amp; Esoteric</a></li>
<li><a href="#" title="Home &amp; Living">Home &amp; Living</a></li>
<li><a href="#" title="Jewellery &amp; Watches">Jewellery &amp; Watches</a></li>
<li><a href="#" title="Militaria">Militaria</a></li>
<li><a href="#" title="Movies &amp; Television">Movies &amp; Television</a></li>
<li><a href="#" title="Music &amp; Instruments">Music &amp; Instruments</a></li>
<li><a href="#" title="Photo &amp; Video">Photo &amp; Video</a></li>
<li><a href="#" title="Property">Property</a></li>
<li><a href="#" title="Sport &amp; Leisure">Sport &amp; Leisure</a></li>
<li><a href="#" title="Stamps">Stamps</a></li>
<li><a href="#" title="Toys &amp; Hobbies">Toys &amp; Hobbies</a></li>
<li><a href="#" title="Travel &amp; Entertainment">Travel &amp; Entertainment</a></li>
<li><a href="#" title="Unusual">Unusual</a></li>
<li><a href="#" title="X- Rated Adult Material">X- Rated Adult Material</a></li>
<li class="topdivider"><a href="#">All Categories&nbsp;→</a></li>
      </ul><br>
</div>   

<div class="col-lg-9 products">

    <div class="col-lg-3">
        <img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>

    </div>

    <div class="col-lg-3">
        <img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>

    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>


<div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>





    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>





    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>





    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>






    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>





    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>




    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>



    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>




    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>



    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>

    <div class="col-lg-3">
<img src="http://via.placeholder.com/120x120" style="float: left">
        <p>Image Name and Brand</p>
        <p>Image Description and other important staff eg prices</p>
    </div>




</div>
</div>
    </div>  
 


<?php
include "includes/footer.html";
?>
