          <div class="product" >
            <div class="slider__dots">
              <a href="#" class="slider__dot" data-pos="0"></a>
              <a href="#" class="slider__dot" data-pos="1"></a>
              <a href="#" class="slider__dot" data-pos="2"></a>
              <a href="#" class="slider__indicator"></a>
            </div>
          </div>
          
          <div class="price" style="">
            <div><span>$ 3.00</span></div>
            <div><a href="#">Bid Now</a></div>  
          </div>

          <div class="slider" data-pos="0" style="">
            <div class="slider__slides">

              <div class="slider__slide">
                <div class="picture">
                  <span>ster</span><img src="https://github.com/emoreno911/UI-to-Code/blob/master/juuce_app/img/bottle3x.png?raw=true">
                  <div class="buttons">
                    <div class="glyph-icon flaticon-like"></div>
                    <div class="glyph-icon flaticon-arrows"></div>
                    <div class="glyph-icon flaticon-share"></div>
                  </div>
                </div>
                <div class="title">
                  <h3>Booster</h3><small><span>&#10004;</span> In Stock</small>
                  <div class="dropdown">
                    <div class="front"> 250 ml </div>
                    <div class="back"> 
                      <ul>
                        <li>250 ml</li>
                        <li>500 ml</li>
                        <li>1 lt</li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation</div>
              </div>
              <div class="slider__slide">
                <div class="picture">
                  <span>Fuel</span> 
                  <img src="https://github.com/emoreno911/UI-to-Code/blob/master/juuce_app/img/bottle2x.png?raw=true">
                  <div class="buttons">
                    <div class="glyph-icon flaticon-like"></div>
                    <div class="glyph-icon flaticon-arrows"></div>
                    <div class="glyph-icon flaticon-share"></div>
                  </div>
                </div>
                <div class="title">
                  <h3>Rocket Fuel</h3><small><span>&#10004;</span> In Stock</small>
                  <div class="dropdown">
                    <div class="front"> 250 ml </div>
                    <div class="back"> 
                      <ul>
                        <li>250 ml</li>
                        <li>500 ml</li>
                        <li>1 lt</li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation</div>
              </div>
              <div class="slider__slide">
                <div class="picture">
                  <span>Red</span><img src="https://github.com/emoreno911/UI-to-Code/blob/master/juuce_app/img/bottle1x.png?raw=true">
                  <div class="buttons">
                    <div class="glyph-icon flaticon-like"></div>
                    <div class="glyph-icon flaticon-arrows"></div>
                    <div class="glyph-icon flaticon-share"></div>
                  </div>
                </div>
                <div class="title">
                  <h3>Big Red</h3><small><span>&#10004;</span> In Stock</small>
                  <div class="dropdown">
                    <div class="front"> 250 ml </div>
                    <div class="back"> 
                      <ul>
                        <li>250 ml</li>
                        <li>500 ml</li>
                        <li>1 lt</li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation</div>
              </div>

            </div>
          </div>