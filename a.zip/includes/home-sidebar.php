      <div class="col-md-3 sidenav categories" style="margin-top: 10px;">
          <h3>Browse Categories</h3>

  <ul class="nav category">
 <li><a href="#" title="Antiques &amp; Collectables">Antiques &amp; Collectables</a></li>
<li><a href="#" title="Art">Art</a></li>
<li><a href="#" title="Baby">Baby</a></li>
<li><a href="#" title="Bikes, Boats &amp; Other Vehicles">Bikes, Boats &amp; Other Vehicles</a></li>
<li><a href="#" title="Books &amp; Education">Books &amp; Education</a></li>
<li><a href="#" title="Business, Farming &amp; Industry">Business, Farming &amp; Industry</a></li>
<li><a href="#" title="Car Parts &amp; Accessories">Car Parts &amp; Accessories</a></li>
<li><a href="#" title="Cars">Cars</a></li>
<li><a href="#" title="Cell Phones &amp; Accessories">Cell Phones &amp; Accessories</a></li>
<li><a href="#" title="Clothing, Shoes &amp; Accessories">Clothing, Shoes &amp; Accessories</a></li>
<li><a href="#" title="Coins &amp; Notes">Coins &amp; Notes</a></li>
<li><a href="#" title="Computers &amp; Networking">Computers &amp; Networking</a></li>
<li><a href="#" title="Crafts">Crafts</a></li>
<li><a href="#" title="Electronics">Electronics</a></li>
<li><a href="#" title="Gaming">Gaming</a></li>
<li><a href="#" title="Garden, Outdoor Living &amp; Pets">Garden, Outdoor Living &amp; Pets</a></li>
<li><a href="#" title="Gemstones &amp; Rocks">Gemstones &amp; Rocks</a></li>
<li><a href="#" title="Gift Vouchers &amp; Coupons">Gift Vouchers &amp; Coupons</a></li>
<li><a href="#" title="Health &amp; Beauty">Health &amp; Beauty</a></li>
<li><a href="#" title="Holistic &amp; Esoteric">Holistic &amp; Esoteric</a></li>
<li><a href="#" title="Home &amp; Living">Home &amp; Living</a></li>
<li><a href="#" title="Jewellery &amp; Watches">Jewellery &amp; Watches</a></li>
<li><a href="#" title="Militaria">Militaria</a></li>

<li class="topdivider"><a href="#">All Categories&nbsp;→</a></li>
      </ul>

</div>