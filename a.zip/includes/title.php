<div class="content_wrapper">
    <div class="categoryheaderinclude">
  <h1 title="Home| Notifications">Home| Notifications</h1>
</div>

<div class="space-clear-10"></div>

    <div class="col-md-12">
        <?php include 'includes/breadcrumb.php'; ?>
    </div>
    </div>