<?php
include "includes/header.php";
?>


<div class="content_wrapper">
<div class="col-md-12">
   
<h1 class="page-header">Settings</h1>

<div class="panel panel-success">
<div class="panel-heading">Notifications</div>
<div class="panel-body">

<table class="table">
<tbody><tr>
<td>
Send notifications to my email inbox
</td>
<td>
        
        Yes
        

</td>
<td>
 <form method="post" class="form-horizontal" action="#">
  <input type="hidden" name="csrfmiddlewaretoken" value="Ye4ZpsvnPe9Bq0UMsToayfNH1CoPCxRwbZg2lmSAHdwouc5ojkSS3kSlRBq6iMVX">
  

        
        <button type="submit" class="btn btn-danger">Turn off Notifications Email</button>
        
</form>
</td>
</tr>
</tbody></table>
</div>
</div>

</div>
</div>



<?php
include "includes/footer.html";
?>
