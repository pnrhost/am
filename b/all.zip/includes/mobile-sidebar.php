<div class="sidebar">
    <div class="brand">A-Mail</div>
    <div class="menu">
        <ul>
            <li><a href="index.php"><i class="glyph-icon flaticon-user"></i> Home </a></li>
            <li><a href="individual_auction.php"><i class="glyph-icon flaticon-user"></i> Single Auction</a></li>
            <li><a href="categories.php"><i class="glyph-icon flaticon-like"></i> Categories</a></li>
            <li><a href="notifications.php"><i class="glyph-icon flaticon-like-1"></i>Notifications</a></li>
            <li><a href="about.php"><i class="glyph-icon flaticon-vision"></i> About us</a></li>
            <li><a href="auctionCreate.php"><i class="glyph-icon flaticon-mail"></i> Create Auction </li>
            <li><a href="composeMessage.php"><i class="glyph-icon flaticon-info"></i> Compose Message</a></li>
            <li><a href="UserLogin.php"><i class="glyph-icon flaticon-user"></i> Login</a></li>
            <li><a href="UserRegistration.php"><i class="glyph-icon flaticon-user"></i> Register</li>
            <li><a href="404.php"><i class="glyph-icon flaticon-vision"></i> 404</a></li>
        </ul>
    </div>
</div>