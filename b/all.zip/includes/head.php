<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>bidorbuy South Africa Online Shopping | Safe and Simple</title>
		<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
		<script src="jquery/jquery.min.js"></script>
		<script src="bootstrap/js/bootstrap.js"></script>
		<script type="text/javascript" src="jquery/bootstrap-hover-dropdown.min.js"></script>
		<script src="js/all.js"></script>
		<link rel="stylesheet" type="text/css" href="css/global.css">
		<link rel="stylesheet" type="text/css" href="css/header.css">
		<link rel="stylesheet" type="text/css" href="css/index.css">
		<link rel="stylesheet" type="text/css" href="css/homepage-sidebar.css">
		<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="css/mobile.css">
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Montserrat|Open+Sans|Nunito:700">
		<link rel="stylesheet" type="text/css" href="https://dl.dropbox.com/s/tb1hmq8sr5gh1mu/flaticon.css">
		<script type="text/javascript" src="https://cdn.jsdelivr.net/domtastic/0.12/domtastic.min.js"></script>
		<script type="text/javascript" src="https://hammerjs.github.io/dist/hammer.min.js"></script>
		</head>